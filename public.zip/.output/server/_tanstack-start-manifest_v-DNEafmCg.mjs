//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DNEafmCg.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "F:/Desktop/PurpleShiftPolls/src/routes/__root.tsx",
		children: ["/", "/admin"],
		preloads: ["/assets/index-CQxtV8WH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CQxtV8WH.js"
		} }]
	},
	"/": {
		filePath: "F:/Desktop/PurpleShiftPolls/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DU6BVATE.js", "/assets/store-Dy4En4gu.js"]
	},
	"/admin": {
		filePath: "F:/Desktop/PurpleShiftPolls/src/routes/admin.tsx",
		children: void 0,
		preloads: ["/assets/admin-Ba1CMRrF.js", "/assets/store-Dy4En4gu.js"]
	}
} });
//#endregion
export { tsrStartManifest };
