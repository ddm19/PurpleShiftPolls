import { n as __toESM } from "../_runtime.mjs";
import { a as getOptionsForQuestion, c as uid, d as upsertQuestion, i as deleteQuestion, l as updateOption, o as getQuestions, r as deleteOption, s as reorderQuestions, t as addOptions, u as uploadLevelImage } from "./store-B5CPgzHj.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-BCGGLy0O.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PASSWORD = "7777";
var AUTH_KEY = "ps_admin_auth";
function AdminPage() {
	const [authed, setAuthed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (typeof window !== "undefined" && sessionStorage.getItem(AUTH_KEY) === "1") setAuthed(true);
	}, []);
	if (!authed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PasswordGate, { onPass: () => setAuthed(true) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminConsole, { onLock: () => {
		sessionStorage.removeItem(AUTH_KEY);
		setAuthed(false);
	} });
}
function PasswordGate({ onPass }) {
	const [pw, setPw] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)(false);
	const submit = () => {
		if (pw === PASSWORD) {
			sessionStorage.setItem(AUTH_KEY, "1");
			onPass();
		} else {
			setErr(true);
			setPw("");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "relative z-10 min-h-screen flex items-center justify-center px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel-cyber p-10 w-full max-w-md slide-in",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center mb-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[10px] tracking-[0.4em] text-muted-foreground mb-2",
						children: "// SECURE TERMINAL"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "neon-text-red text-3xl font-bold tracking-widest flicker",
						children: "ACCESS GATE"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "block text-[10px] tracking-widest text-muted-foreground mb-2",
					children: "AUTH KEY"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					autoFocus: true,
					type: "password",
					inputMode: "numeric",
					value: pw,
					onChange: (e) => {
						setPw(e.target.value);
						setErr(false);
					},
					onKeyDown: (e) => e.key === "Enter" && submit(),
					className: `input-cyber w-full text-center text-2xl tracking-[0.5em] ${err ? "neon-border-red" : ""}`,
					placeholder: "••••"
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "neon-text-red text-xs mt-3 tracking-widest text-center",
					children: "✕ AUTH DENIED"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: submit,
					className: "btn-neon-purple w-full py-3 mt-6",
					children: "Authenticate"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "text-xs text-muted-foreground hover:neon-text-blue tracking-widest",
						children: "← BACK TO SURVEY"
					})
				})
			]
		})
	});
}
function AdminConsole({ onLock }) {
	const [questions, setQuestions] = (0, import_react.useState)([]);
	const [editing, setEditing] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const refresh = (0, import_react.useCallback)(async () => {
		try {
			setQuestions(await getQuestions());
		} catch (e) {
			setError(e?.message ?? String(e));
		}
	}, []);
	(0, import_react.useEffect)(() => {
		refresh();
	}, [refresh]);
	const newQuestion = () => {
		setEditing({
			id: uid(),
			type: "text",
			text_prompt: "",
			order: questions.length + 1,
			choices: []
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative z-10 min-h-screen",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "px-6 py-5 flex items-center justify-between border-b border-border/40",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "neon-text-purple text-xl font-bold tracking-[0.3em]",
				children: "ADMIN"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "neon-text-red text-xl font-bold tracking-[0.3em] ml-1",
				children: "::CONSOLE"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/",
					className: "btn-neon-blue px-4 py-2 text-xs",
					children: "View Survey"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: onLock,
					className: "btn-neon-red px-4 py-2 text-xs",
					children: "Lock"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "max-w-6xl mx-auto px-6 py-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between mb-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-bold neon-text-blue tracking-widest",
						children: "QUESTIONS"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: newQuestion,
						className: "btn-neon-purple px-5 py-2",
						children: "+ New Question"
					})]
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "panel-cyber p-4 neon-border-red mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "neon-text-red text-xs tracking-widest mb-1",
						children: "✕ ERROR"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "text-xs text-muted-foreground whitespace-pre-wrap",
						children: error
					})]
				}),
				editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionEditor, {
					question: editing,
					onSave: async (q) => {
						try {
							await upsertQuestion(q);
							setEditing(null);
							await refresh();
						} catch (e) {
							setError(e?.message ?? String(e));
						}
					},
					onCancel: () => setEditing(null)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3 mt-6",
					children: [questions.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-muted-foreground text-center py-12",
						children: "// no questions defined. click \"new question\" to begin."
					}), questions.map((q) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionRow, {
						q,
						onEdit: () => setEditing(q),
						onDelete: async () => {
							if (confirm(`Delete "${q.text_prompt}"?`)) try {
								await deleteQuestion(q.id);
								await refresh();
							} catch (e) {
								setError(e?.message ?? String(e));
							}
						},
						onMove: async (dir) => {
							const idx = questions.findIndex((x) => x.id === q.id);
							const swap = idx + dir;
							if (swap < 0 || swap >= questions.length) return;
							const next = [...questions];
							[next[idx], next[swap]] = [next[swap], next[idx]];
							try {
								await reorderQuestions(next);
								await refresh();
							} catch (e) {
								setError(e?.message ?? String(e));
							}
						}
					}, q.id))]
				})
			]
		})]
	});
}
function QuestionRow({ q, onEdit, onDelete, onMove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel-cyber p-5 flex items-center gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "text-xs text-muted-foreground w-10",
				children: ["#", String(q.order).padStart(2, "0")]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[10px] tracking-widest neon-text-blue mb-1",
					children: q.type.toUpperCase().replace("_", " ")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-bold truncate",
					children: q.text_prompt || "(untitled)"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn-neon-blue px-2 py-1 text-xs",
						onClick: () => onMove(-1),
						children: "↑"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn-neon-blue px-2 py-1 text-xs",
						onClick: () => onMove(1),
						children: "↓"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn-neon-blue px-3 py-1 text-xs",
						onClick: onEdit,
						children: "Edit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "btn-neon-red px-3 py-1 text-xs",
						onClick: onDelete,
						children: "Del"
					})
				]
			})
		]
	});
}
function QuestionEditor({ question, onSave, onCancel }) {
	const [q, setQ] = (0, import_react.useState)(question);
	const [choicesText, setChoicesText] = (0, import_react.useState)((question.choices ?? []).join("\n"));
	const save = () => {
		onSave({
			...q,
			choices: q.type === "multiple_choice" ? choicesText.split("\n").map((s) => s.trim()).filter(Boolean) : void 0
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel-cyber p-6 neon-border-purple slide-in",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid md:grid-cols-3 gap-4 mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "md:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Prompt" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "input-cyber w-full",
						value: q.text_prompt,
						onChange: (e) => setQ({
							...q,
							text_prompt: e.target.value
						}),
						placeholder: "Enter the question prompt..."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Type" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: "input-cyber w-full",
					value: q.type,
					onChange: (e) => setQ({
						...q,
						type: e.target.value
					}),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "text",
							children: "Text Input"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "multiple_choice",
							children: "Multiple Choice"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "level_gallery",
							children: "Level Gallery"
						})
					]
				})] })]
			}),
			q.type === "multiple_choice" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Choices (one per line)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					className: "input-cyber w-full font-mono",
					rows: 4,
					value: choicesText,
					onChange: (e) => setChoicesText(e.target.value),
					placeholder: "Option A\nOption B\nOption C"
				})]
			}),
			q.type === "level_gallery" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelManager, { questionId: q.id }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex justify-end gap-3 mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn-neon-red px-5 py-2",
					onClick: onCancel,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn-neon-purple px-6 py-2",
					onClick: save,
					children: "Save Question"
				})]
			})
		]
	});
}
function Label({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: "block text-[10px] tracking-widest text-muted-foreground mb-1",
		children
	});
}
function LevelManager({ questionId }) {
	const [opts, setOpts] = (0, import_react.useState)([]);
	const [pending, setPending] = (0, import_react.useState)([]);
	const [dragging, setDragging] = (0, import_react.useState)(false);
	const [uploading, setUploading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const inputRef = (0, import_react.useRef)(null);
	const refresh = (0, import_react.useCallback)(async () => {
		try {
			setOpts(await getOptionsForQuestion(questionId));
		} catch (e) {
			setError(e?.message ?? String(e));
		}
	}, [questionId]);
	(0, import_react.useEffect)(() => {
		refresh();
	}, [refresh]);
	const handleFiles = (files) => {
		if (!files || files.length === 0) return;
		const arr = [];
		for (const f of Array.from(files)) {
			if (!f.type.startsWith("image/")) continue;
			arr.push({
				id: uid(),
				file: f,
				title: f.name.replace(/\.[^.]+$/, ""),
				preview: URL.createObjectURL(f)
			});
		}
		setPending((p) => [...p, ...arr]);
	};
	const commit = async () => {
		setUploading(true);
		setError(null);
		try {
			const uploaded = [];
			for (const p of pending) {
				const { image_url, image_path } = await uploadLevelImage(questionId, p.file);
				uploaded.push({
					id: uid(),
					question_id: questionId,
					title: p.title,
					image_url,
					image_path
				});
			}
			await addOptions(uploaded);
			pending.forEach((p) => URL.revokeObjectURL(p.preview));
			setPending([]);
			await refresh();
		} catch (e) {
			setError(e?.message ?? String(e));
		} finally {
			setUploading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Level Images" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				onDragOver: (e) => {
					e.preventDefault();
					setDragging(true);
				},
				onDragLeave: () => setDragging(false),
				onDrop: (e) => {
					e.preventDefault();
					setDragging(false);
					handleFiles(e.dataTransfer.files);
				},
				onClick: () => inputRef.current?.click(),
				className: `border-2 border-dashed p-8 text-center cursor-pointer transition-all ${dragging ? "neon-border-purple bg-primary/5" : "border-border hover:border-primary/60"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "neon-text-purple text-3xl mb-2",
						children: "⬆"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "tracking-widest text-sm",
						children: "DROP IMAGES OR CLICK TO UPLOAD"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-muted-foreground mt-1",
						children: "multiple files supported"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: inputRef,
						type: "file",
						multiple: true,
						accept: "image/*",
						className: "hidden",
						onChange: (e) => {
							handleFiles(e.target.files);
							e.target.value = "";
						}
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "neon-text-red text-xs mt-2 tracking-widest",
				children: ["✕ ", error]
			}),
			pending.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 panel-cyber p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[10px] tracking-widest neon-text-blue mb-3",
						children: ["PENDING UPLOAD · ", pending.length]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-2",
						children: pending.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-14 flex justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: p.preview,
										alt: "",
										className: "block max-h-14 max-w-14 w-auto h-auto"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "input-cyber flex-1",
									value: p.title,
									onChange: (e) => {
										const next = [...pending];
										next[i] = {
											...p,
											title: e.target.value
										};
										setPending(next);
									},
									placeholder: "Level title..."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "btn-neon-red px-3 py-1 text-xs",
									onClick: () => {
										URL.revokeObjectURL(p.preview);
										setPending(pending.filter((x) => x.id !== p.id));
									},
									children: "✕"
								})
							]
						}, p.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: commit,
						disabled: uploading,
						className: "btn-neon-purple px-5 py-2 mt-4",
						children: uploading ? "Uploading..." : `Save ${pending.length} Level${pending.length === 1 ? "" : "s"}`
					})
				]
			}),
			opts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[10px] tracking-widest text-muted-foreground mb-3",
					children: ["CURRENT LEVELS · ", opts.length]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 md:grid-cols-3 gap-3",
					children: opts.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel-cyber p-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex justify-center mb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: o.image_url,
									alt: o.title,
									className: "block max-h-48 max-w-full w-auto h-auto"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								className: "input-cyber w-full text-sm mb-2",
								defaultValue: o.title,
								onBlur: async (e) => {
									const title = e.target.value;
									if (title !== o.title) {
										await updateOption({
											...o,
											title
										});
										await refresh();
									}
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "btn-neon-red w-full py-1 text-xs",
								onClick: async () => {
									if (confirm(`Delete "${o.title}"?`)) {
										await deleteOption(o.id);
										await refresh();
									}
								},
								children: "Delete"
							})
						]
					}, o.id))
				})]
			})
		]
	});
}
//#endregion
export { AdminPage as component };
