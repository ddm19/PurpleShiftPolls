import { t as createClient } from "../_libs/supabase__supabase-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-B5CPgzHj.js
var url = "";
var anonKey = "";
console.warn("[supabase] Missing VITE_SUPABASE_URL or VITE_SUPABASE_PUBLISHABLE_KEY. Set them in .env — see supabase.md.");
var supabase = createClient(url, anonKey, { auth: {
	persistSession: false,
	autoRefreshToken: false
} });
var LEVELS_BUCKET = "level-images";
var uid = () => globalThis.crypto?.randomUUID?.() ?? `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`;
async function getQuestions() {
	const { data, error } = await supabase.from("questions").select("id, type, text_prompt, order, choices").order("order", { ascending: true });
	if (error) throw error;
	return data ?? [];
}
async function upsertQuestion(q) {
	const payload = {
		id: q.id,
		type: q.type,
		text_prompt: q.text_prompt,
		order: q.order,
		choices: q.type === "multiple_choice" ? q.choices ?? [] : null
	};
	const { error } = await supabase.from("questions").upsert(payload);
	if (error) throw error;
}
async function deleteQuestion(id) {
	const paths = (await getOptionsForQuestion(id)).map((o) => o.image_path).filter(Boolean);
	if (paths.length > 0) await supabase.storage.from(LEVELS_BUCKET).remove(paths);
	const { error } = await supabase.from("questions").delete().eq("id", id);
	if (error) throw error;
}
async function reorderQuestions(qs) {
	const updates = qs.map((q, i) => supabase.from("questions").update({ order: i + 1 }).eq("id", q.id));
	const results = await Promise.all(updates);
	for (const r of results) if (r.error) throw r.error;
}
async function getOptionsForQuestion(qid) {
	const { data, error } = await supabase.from("level_options").select("id, question_id, title, image_url, image_path").eq("question_id", qid).order("created_at", { ascending: true });
	if (error) throw error;
	return data ?? [];
}
/**
* Upload a single image to the storage bucket and return its public URL +
* the storage path (used later for deletion).
*/
async function uploadLevelImage(questionId, file) {
	const ext = file.name.split(".").pop()?.toLowerCase() || "png";
	const path = `${questionId}/${uid()}.${ext}`;
	const { error } = await supabase.storage.from(LEVELS_BUCKET).upload(path, file, {
		contentType: file.type || `image/${ext}`,
		upsert: false
	});
	if (error) throw error;
	const { data } = supabase.storage.from(LEVELS_BUCKET).getPublicUrl(path);
	return {
		image_url: data.publicUrl,
		image_path: path
	};
}
async function addOptions(newOpts) {
	if (newOpts.length === 0) return;
	const { error } = await supabase.from("level_options").insert(newOpts.map((o) => ({
		id: o.id,
		question_id: o.question_id,
		title: o.title,
		image_url: o.image_url,
		image_path: o.image_path ?? null
	})));
	if (error) throw error;
}
async function updateOption(opt) {
	const { error } = await supabase.from("level_options").update({
		title: opt.title,
		image_url: opt.image_url
	}).eq("id", opt.id);
	if (error) throw error;
}
async function deleteOption(id) {
	const { data, error: selErr } = await supabase.from("level_options").select("image_path").eq("id", id).maybeSingle();
	if (selErr) throw selErr;
	if (data?.image_path) await supabase.storage.from(LEVELS_BUCKET).remove([data.image_path]);
	const { error } = await supabase.from("level_options").delete().eq("id", id);
	if (error) throw error;
}
async function addResponses(rs) {
	if (rs.length === 0) return;
	const { error } = await supabase.from("responses").insert(rs.map((r) => ({
		question_id: r.question_id,
		answer: r.answer
	})));
	if (error) throw error;
}
//#endregion
export { getOptionsForQuestion as a, uid as c, upsertQuestion as d, deleteQuestion as i, updateOption as l, addResponses as n, getQuestions as o, deleteOption as r, reorderQuestions as s, addOptions as t, uploadLevelImage as u };
