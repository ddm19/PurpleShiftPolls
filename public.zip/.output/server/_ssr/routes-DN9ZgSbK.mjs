import { n as __toESM } from "../_runtime.mjs";
import { a as getOptionsForQuestion, n as addResponses, o as getQuestions } from "./store-B5CPgzHj.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DN9ZgSbK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SurveyPage() {
	const [questions, setQuestions] = (0, import_react.useState)([]);
	const [idx, setIdx] = (0, import_react.useState)(0);
	const [answers, setAnswers] = (0, import_react.useState)({});
	const [done, setDone] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)(null);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let alive = true;
		getQuestions().then((qs) => {
			if (!alive) return;
			setQuestions(qs);
		}).catch((e) => alive && setError(e?.message ?? String(e))).finally(() => alive && setLoading(false));
		return () => {
			alive = false;
		};
	}, []);
	const current = questions[idx];
	const next = async (value) => {
		if (!current) return;
		const updated = {
			...answers,
			[current.id]: value
		};
		setAnswers(updated);
		if (idx + 1 >= questions.length) try {
			setSubmitting(true);
			await addResponses(Object.entries(updated).map(([question_id, answer]) => ({
				question_id,
				answer
			})));
			setDone(true);
		} catch (e) {
			setError(e?.message ?? String(e));
		} finally {
			setSubmitting(false);
		}
		else setIdx(idx + 1);
	};
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted-foreground",
		children: "// loading survey grid..."
	}) });
	if (error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel-cyber p-6 sm:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "neon-text-red text-lg sm:text-xl mb-3 tracking-widest",
				children: "✕ CONNECTION ERROR"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground text-sm mb-2",
				children: "// could not reach the mainframe."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "text-xs text-muted-foreground whitespace-pre-wrap",
				children: error
			})
		]
	}) });
	if (questions.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "panel-cyber p-8 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-muted-foreground",
			children: [
				"// no questions configured. visit",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/admin",
					className: "neon-text-blue",
					children: "/admin"
				}),
				" ",
				"to set them up."
			]
		})
	}) });
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "slide-in text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "neon-text-purple text-4xl sm:text-5xl font-bold mb-4 flicker",
				children: "TRANSMISSION RECEIVED"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground mb-8",
				children: "// your input has been logged to the mainframe."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn-neon-blue px-8 py-3",
				onClick: () => {
					setAnswers({});
					setIdx(0);
					setDone(false);
				},
				children: "New Operator"
			})
		]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressBar, {
		current: idx + 1,
		total: questions.length
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "slide-in",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuestionView, {
			question: current,
			onAnswer: next,
			disabled: submitting
		})
	}, current.id)] });
}
function Shell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative z-10 min-h-screen flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "px-4 py-4 sm:px-6 sm:py-5 flex items-center justify-between border-b border-border/40",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "neon-text-purple text-lg sm:text-xl font-bold tracking-[0.3em]",
					children: "PURPLE"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "neon-text-red text-lg sm:text-xl font-bold tracking-[0.3em] ml-1",
					children: "::SHIFT"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[10px] text-muted-foreground tracking-widest mt-0.5",
					children: "OPERATOR SURVEY v0.1"
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/admin",
				className: "text-xs text-muted-foreground hover:neon-text-blue tracking-widest",
				children: "[ ADMIN ]"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "flex-1 flex items-center justify-center px-4 py-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-full max-w-4xl",
				children
			})
		})]
	});
}
function ProgressBar({ current, total }) {
	const pct = current / total * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6 sm:mb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex justify-between text-[10px] tracking-widest text-muted-foreground mb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				"QUERY ",
				String(current).padStart(2, "0"),
				" / ",
				String(total).padStart(2, "0")
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "neon-text-blue",
				children: [Math.round(pct), "%"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "h-1 bg-muted overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-full transition-all duration-500",
				style: {
					width: `${pct}%`,
					background: "linear-gradient(90deg, var(--neon-blue), var(--neon-purple), var(--neon-red))",
					boxShadow: "0 0 12px var(--neon-purple)"
				}
			})
		})]
	});
}
function QuestionView({ question, onAnswer, disabled }) {
	if (question.type === "text") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextQuestion, {
		q: question,
		onAnswer,
		disabled
	});
	if (question.type === "multiple_choice") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChoiceQuestion, {
		q: question,
		onAnswer,
		disabled
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GalleryQuestion, {
		q: question,
		onAnswer,
		disabled
	});
}
function Prompt({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
		className: "text-xl sm:text-2xl md:text-3xl font-bold mb-6 sm:mb-8 leading-snug",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "neon-text-purple mr-2",
			children: ">"
		}), children]
	});
}
function TextQuestion({ q, onAnswer, disabled }) {
	const [val, setVal] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel-cyber p-6 sm:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prompt, { children: q.text_prompt }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				autoFocus: true,
				className: "input-cyber w-full text-base sm:text-lg",
				placeholder: "enter response...",
				value: val,
				onChange: (e) => setVal(e.target.value),
				onKeyDown: (e) => {
					if (e.key === "Enter" && val.trim() && !disabled) onAnswer(val.trim());
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn-neon-purple px-8 py-3",
					disabled: !val.trim() || disabled,
					onClick: () => onAnswer(val.trim()),
					children: "Transmit →"
				})
			})
		]
	});
}
function ChoiceQuestion({ q, onAnswer, disabled }) {
	const [selected, setSelected] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel-cyber p-6 sm:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prompt, { children: q.text_prompt }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: (q.choices ?? []).map((c) => {
					const isSel = selected === c;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setSelected(c),
						className: `w-full text-left px-4 py-3 sm:px-5 sm:py-4 border transition-all tracking-wide ${isSel ? "neon-border-purple neon-text-purple" : "border-border hover:border-primary/60"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground mr-3",
							children: [
								"[",
								isSel ? "■" : " ",
								"]"
							]
						}), c]
					}, c);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn-neon-purple px-8 py-3",
					disabled: !selected || disabled,
					onClick: () => selected && onAnswer(selected),
					children: "Confirm →"
				})
			})
		]
	});
}
function GalleryQuestion({ q, onAnswer, disabled }) {
	const [options, setOptions] = (0, import_react.useState)([]);
	const scrollerRef = (0, import_react.useRef)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [focusedIdx, setFocusedIdx] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let alive = true;
		getOptionsForQuestion(q.id).then((opts) => {
			if (alive) {
				setOptions(opts);
				if (opts.length > 0) {
					const startIdx = Math.floor(opts.length / 2);
					setFocusedIdx(startIdx);
					setTimeout(() => scrollTo(startIdx, "auto"), 50);
				}
			}
		}).finally(() => alive && setLoading(false));
		return () => {
			alive = false;
		};
	}, [q.id]);
	(0, import_react.useEffect)(() => {
		const container = scrollerRef.current;
		if (!container) return;
		let timeout;
		const onScroll = () => {
			clearTimeout(timeout);
			timeout = setTimeout(() => {
				const cards = container.querySelectorAll("[data-card]");
				const center = container.scrollLeft + container.clientWidth / 2;
				let best = 0;
				let bestDist = Infinity;
				cards.forEach((card, i) => {
					const cardCenter = card.offsetLeft + card.offsetWidth / 2;
					const d = Math.abs(cardCenter - center);
					if (d < bestDist) {
						bestDist = d;
						best = i;
					}
				});
				setFocusedIdx(best);
			}, 100);
		};
		container.addEventListener("scroll", onScroll, { passive: true });
		return () => container.removeEventListener("scroll", onScroll);
	}, [options]);
	const focused = (0, import_react.useMemo)(() => options[focusedIdx], [options, focusedIdx]);
	const scrollTo = (index, behavior = "smooth") => {
		const container = scrollerRef.current;
		if (!container) return;
		const card = container.querySelectorAll("[data-card]")[index];
		if (card) card.scrollIntoView({
			behavior,
			block: "nearest",
			inline: "center"
		});
	};
	const scrollPrev = () => {
		const newIndex = Math.max(0, focusedIdx - 1);
		scrollTo(newIndex);
	};
	const scrollNext = () => {
		const newIndex = Math.min(options.length - 1, focusedIdx + 1);
		scrollTo(newIndex);
	};
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel-cyber p-8 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prompt, { children: q.text_prompt }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted-foreground",
			children: "// fetching level data..."
		})]
	});
	if (options.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel-cyber p-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prompt, { children: q.text_prompt }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted-foreground mb-6",
				children: "// no level data uploaded yet. visit /admin to load levels."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn-neon-blue px-6 py-2",
				onClick: () => onAnswer("__skipped__"),
				children: "Skip →"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Prompt, { children: q.text_prompt }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: scrollerRef,
					className: "scrollbar-cyber flex gap-4 md:gap-8 overflow-x-auto snap-x snap-mandatory pb-6",
					style: {
						paddingLeft: "calc(50% - 140px)",
						paddingRight: "calc(50% - 140px)",
						scrollPaddingLeft: "calc(50% - 140px)",
						scrollPaddingRight: "calc(50% - 140px)"
					},
					children: options.map((opt, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LevelCard, {
						opt,
						active: i === focusedIdx
					}, opt.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: scrollPrev,
					disabled: focusedIdx === 0,
					className: "absolute left-0 sm:left-4 top-1/2 -translate-y-1/2 btn-neon-blue p-2 w-10 h-10 sm:w-12 sm:h-12 rounded-full disabled:opacity-20 disabled:cursor-not-allowed z-10",
					"aria-label": "Previous level",
					children: "<"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: scrollNext,
					disabled: focusedIdx === options.length - 1,
					className: "absolute right-0 sm:right-4 top-1/2 -translate-y-1/2 btn-neon-blue p-2 w-10 h-10 sm:w-12 sm:h-12 rounded-full disabled:opacity-20 disabled:cursor-not-allowed z-10",
					"aria-label": "Next level",
					children: ">"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 sm:mt-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-[10px] tracking-widest text-muted-foreground mb-3",
					children: [
						"SELECTED // ",
						focusedIdx + 1,
						" OF ",
						options.length
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-8 mb-3 text-lg neon-text-purple font-bold tracking-widest transition-opacity duration-300",
					children: focused?.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "btn-neon-purple px-10 py-4 text-base",
					disabled: disabled || !focused,
					onClick: () => focused && onAnswer(focused.id),
					children: "▶ Vote For This Level"
				})
			]
		})
	] });
}
function LevelCard({ opt, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-card": true,
		className: `snap-center shrink-0 w-[320px] sm:w-[480px] md:w-[600px] flex justify-center transition-all duration-300 ${active ? "scale-100 opacity-100" : "scale-90 opacity-60"}`,
		children: opt.image_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: opt.image_url,
			alt: opt.title,
			className: "block max-h-[62vh] max-w-full w-auto h-auto"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-48 w-full bg-muted flex items-center justify-center text-muted-foreground",
			children: "no image"
		})
	});
}
//#endregion
export { SurveyPage as component };
